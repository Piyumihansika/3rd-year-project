module.exports = {
  publicPath: '/'
}
