<template>
	<BarChart/>
</template>

<script>
import BarChart from './BarChart.vue'
export default {
	name:"SalesIncome",
    components: {
    BarChart
    }
}    
</script>