<template>
	<LineChart/>
</template>

<script>
import LineChart from './LineChart.vue'
export default {
	name:"SalesSummary",
    components: {
    LineChart
    }
}    
</script>